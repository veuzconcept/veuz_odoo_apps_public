OH Reward/Warning
---------------------
Supporting Addon for Open HRMS, Managing Official Announcements

Connect with experts
--------------------

If you have any question/queries/additional works on OpenHRMS or this module, You can drop an email directly to Cybrosys.

Contacts
--------
info - info@cybrosys.com
Jesni Banu - odoo@cybrosys.com
Version 14: Naveen V @cybrosys, Contact: odoo@cybrosys.com


Website:
https://www.openhrms.com
https://www.cybrosys.com
