# -*- coding: utf-8 -*-
from . import salary_advance
from . import hr_advance_payslip
from . import salary_structure
