## Module <hr_payroll_account_community>

#### 20.10.2021
#### Version 16.0.1.0.0
#### ADD
- Initial commit

